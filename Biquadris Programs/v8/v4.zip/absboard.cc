#include "absboard.h"

AbsBoard::~AbsBoard() {}