#include "abslevel.h"

AbsLevel::~AbsLevel() {}